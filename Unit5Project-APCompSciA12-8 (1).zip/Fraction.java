 /////////////////////////// Fraction class with variables and contructor

class Fraction {
  int numerator;
  int denominator;

  public Fraction(int n, int d){
   numerator = n;
   denominator = d;

 /////////////////////////// gets and sets Numerators and Denominators

    
  }
  public int getNumerator(){
   return this.numerator;
    
  }

  public void setNumerator(int nn){
    this.numerator = nn;

    
  }

  public int getDenominator(){
    return this.denominator;
    
  }

  public void setDenominator(int nd){
    this.denominator = nd;
  }

 /////////////////////////// add method
  
  public static Fraction add(Fraction f1, Fraction f2){
    Fraction answer = new Fraction(0,0);
    for (int d = 1; d > -1; d++){
     if((double)d % f1.getDenominator() == (double)0  && (double)d % f2.getDenominator() == (double)0){
       f1.setNumerator((d/f1.getDenominator()) * f1.getNumerator());
       f2.setNumerator((d/f2.getDenominator()) * f2.getNumerator());
       answer.setNumerator(f1.getNumerator() + f2.getNumerator());
       answer.setDenominator(d);
       break;
      }
     }
      
    return answer;
      
     }


  /////////////////////////// subtract method 
  public static Fraction subtract(Fraction f1, Fraction f2){
    Fraction answer = new Fraction(0,0);
    for (int d = 1; d > -1; d++){
     if((double)d % f1.getDenominator() == (double)0  && (double)d % f2.getDenominator() == (double)0){
       f1.setNumerator((d/f1.getDenominator()) * f1.getNumerator());
       f2.setNumerator((d/f2.getDenominator()) * f2.getNumerator());
       answer.setNumerator(f1.getNumerator() - f2.getNumerator());
       answer.setDenominator(d);
       break;
      }
     }
      
    return answer;
      
     }

 /////////////////////////// multiply method

  
    public static Fraction multiply(Fraction f1, Fraction f2){
     Fraction answer = new Fraction(0,0);
     answer.setNumerator(f1.getNumerator() * f2.getNumerator());
     answer.setDenominator(f1.getDenominator() * f2.getDenominator());
     return answer;
      
     }

 /////////////////////////// divide method

  
    public static Fraction divide(Fraction f1, Fraction f2){
     Fraction answer = new Fraction(0,0);
     answer.setNumerator(f1.getNumerator() * f2.getDenominator());
     answer.setDenominator(f1.getDenominator() * f2.getNumerator());
     return answer;
      
     }

 /////////////////////////// simplify method

  
    public static Fraction simplify(Fraction f){
     int numerator = f.getNumerator();
     for(int n = 2; n <= numerator; n++){
      if (f.getNumerator() % n == 0 && f.getDenominator() % n == 0){
       f.setNumerator(f.getNumerator() / n);
       f.setDenominator(f.getDenominator() / n);
       n--;
      }
     } 
     return f;

    }

 ///////////////////////////  method that checks to see if two fractions are equal
  
  
    public static Boolean isEqual(Fraction f1, Fraction f2){
     Fraction.simplify(f1);
     Fraction.simplify(f2);
     return ((f1.getNumerator() == f2.getNumerator()) && (f1.getDenominator() == f2.getDenominator()));
    
     } 

 ///////////////////////////  method that checks to which of two fractions are larger
  
    public static String larger(Fraction f1, Fraction f2){
     Fraction.simplify(f1);
     Fraction.simplify(f2);
     if ((double)f1.getNumerator()/(double)f1.getDenominator() > (double)f2.getNumerator()/(double)f2.getDenominator()){
       return String.valueOf(f1.getNumerator()) + "/" + String.valueOf(f1.getDenominator());
       
     }
     else if ((double)f2.getNumerator()/(double)f2.getDenominator() > (double)f1.getNumerator()/(double)f1.getDenominator()){
       return String.valueOf(f2.getNumerator()) + "/" + String.valueOf(f2.getDenominator());
       
     }
     else{
      return "equal";
       
     }
    
     } 

 ///////////////////////////  method that prints whole version of a fraction

  
    public static String whole(Fraction f){
     Fraction.simplify(f);
     int w = (f.getNumerator()/f.getDenominator());
     int d = f.getDenominator();
     int n = f.getNumerator() - (d * w);
     if (n == 0){
      return String.valueOf(w);
     }
     else{
       return String.valueOf(w) + "(" + String.valueOf(n) + "/" + String.valueOf(d) + ")";
        
     }

       
     }



 ///////////////////////////  prints out a fraction itself

      
    public String toString(){
     return String.valueOf(this.getNumerator()) + "/" + String.valueOf(this.getDenominator());

      
    }

       

      
    

     
      
    }
    
  

  
  
