//Name: Anthony Cooper & Guilherme Rodrigues
//Date: 1/11/23
//Title: Fraction Calculator
//Descrpition: This is a basic Java fraction calculator.


/////////////////////////// gets operations and repeats until user inputs "exit"
import java.util.Scanner;

class Main {
  public static void main(String[] args) {
     
    System.out.println("Welcome to the fraction calculator! \nEnter \"exit\" to end the program.");
    Scanner input = new Scanner(System.in);
    Boolean done = false;
    while (done == false){
      System.out.print("Enter operation (no spaces): ");
      String operation = input.nextLine();

 /////////////////////////// ends the program


      if (operation.equals("exit")){
       System.out.println("Program closed");
       done = true;
      }

 /////////////////////////// simplifies a fraction
        
      else if (operation.substring(0,8).equals("simplify")){
  
        int index = 0;
        String numeratorString = "";
        for (int n = 9; n < operation.indexOf("/"); n++){
         numeratorString += String.valueOf(operation.substring(n, n+1));
         index = n;
         }
  
        String denominatorString = "";
        for (int n = index + 2; n < operation.indexOf(")"); n++){
         denominatorString += String.valueOf(operation.substring(n, n+1));
         }

        
        Fraction fraction = new Fraction(Integer.valueOf(numeratorString), Integer.valueOf(denominatorString));
         System.out.println(Fraction.simplify(fraction).getNumerator() + "/" + Fraction.simplify(fraction).getDenominator());

        
      }

/////////////////////////// checks if two fractions are equal
        
      else if (operation.substring(0, 7).equals("isequal")){
        int index1 = 0;
        String numerator1s = "";
        for (int n = 8; n < operation.indexOf("/"); n++){
         numerator1s += String.valueOf(operation.substring(n, n+1));
         index1 = n;
         }
    
        int numerator1 = Integer.valueOf(numerator1s);
        System.out.println(numerator1s);
    
        int index2 = 0;
        String denominator1s = "";
        for (int n = index1 + 2; n < operation.indexOf(")"); n++){
         denominator1s += String.valueOf(operation.substring(n, n+1));
         index2 = n;
         }
    
        int denominator1 = Integer.valueOf(denominator1s);
        System.out.println(denominator1s);
    
        
        int index3 = 0;
        String numerator2s = "";
        for (int n = index2 + 3; n < operation.indexOf("/", index2 + 3); n++){
         numerator2s += String.valueOf(operation.substring(n, n+1));
         index3 = n;
         }
    
        int numerator2 = Integer.valueOf(numerator2s);
        System.out.println(numerator2);
    
        
        int index4 = 0;
        String denominator2s = "";
        for (int n = index3 + 2; n < operation.indexOf(")", index2 + 2); n++){
         denominator2s += String.valueOf(operation.substring(n, n+1));
         index4 = n;
         }
    
        int denominator2 = Integer.valueOf(denominator2s);
        System.out.println(denominator2s);
         
        Fraction fraction1 = new Fraction(numerator1, denominator1);
        Fraction fraction2 = new Fraction(numerator2, denominator2);
        System.out.println(Fraction.isEqual(fraction1,fraction2)); 
      }

/////////////////////////// checks which fraction is larger out of two fractions        
    else if (operation.substring(0, 6).equals("larger")){
        int index1 = 0;
        String numerator1s = "";
        for (int n = 7; n < operation.indexOf("/"); n++){
         numerator1s += String.valueOf(operation.substring(n, n+1));
         index1 = n;
         }
    
        int numerator1 = Integer.valueOf(numerator1s);
        System.out.println(numerator1s);
    
        int index2 = 0;
        String denominator1s = "";
        for (int n = index1 + 2; n < operation.indexOf(")"); n++){
         denominator1s += String.valueOf(operation.substring(n, n+1));
         index2 = n;
         }
    
        int denominator1 = Integer.valueOf(denominator1s);
        System.out.println(denominator1s);
    
        
        int index3 = 0;
        String numerator2s = "";
        for (int n = index2 + 3; n < operation.indexOf("/", index2 + 3); n++){
         numerator2s += String.valueOf(operation.substring(n, n+1));
         index3 = n;
         }
    
        int numerator2 = Integer.valueOf(numerator2s);
        System.out.println(numerator2);
    
        
        int index4 = 0;
        String denominator2s = "";
        for (int n = index3 + 2; n < operation.indexOf(")", index2 + 2); n++){
         denominator2s += String.valueOf(operation.substring(n, n+1));
         index4 = n;
         }
    
        int denominator2 = Integer.valueOf(denominator2s);
        System.out.println(denominator2s);
         
        Fraction fraction1 = new Fraction(numerator1, denominator1);
        Fraction fraction2 = new Fraction(numerator2, denominator2);
        System.out.println(Fraction.larger(fraction1,fraction2)); 
      }

/////////////////////////// shows the whole version of a fraction
      
    else if (operation.substring(0, 5).equals("whole")){
        int index1 = 0;
        String numerator1s = "";
        for (int n = 6; n < operation.indexOf("/"); n++){
         numerator1s += String.valueOf(operation.substring(n, n+1));
         index1 = n;
         }
    
        int numerator1 = Integer.valueOf(numerator1s);
        System.out.println(numerator1s);
    
        int index2 = 0;
        String denominator1s = "";
        for (int n = index1 + 2; n < operation.indexOf(")"); n++){
         denominator1s += String.valueOf(operation.substring(n, n+1));
         index2 = n;
         }
    
        int denominator1 = Integer.valueOf(denominator1s);
        System.out.println(denominator1);
    
        Fraction fraction1 = new Fraction(numerator1,denominator1);
        System.out.println(Fraction.whole(fraction1)); 
      }

/////////////////////////// if the user types an equation, grabs all numbers and symbols needed
      
      else{
        
        int index1 = 0;
        String numerator1s = "";
        for (int n = 1; n < operation.indexOf("/"); n++){
         numerator1s += String.valueOf(operation.substring(n, n+1));
         index1 = n;
         }
    
        int numerator1 = Integer.valueOf(numerator1s);
        System.out.println(numerator1s);
    
        int index2 = 0;
        String denominator1s = "";
        for (int n = index1 + 2; n < operation.indexOf(")"); n++){
         denominator1s += String.valueOf(operation.substring(n, n+1));
         index2 = n;
         }
    
        int denominator1 = Integer.valueOf(denominator1s);
        System.out.println(denominator1s);
    
        
        int index3 = 0;
        String numerator2s = "";
        for (int n = index2 + 4; n < operation.indexOf("/", index2 + 3); n++){
         numerator2s += String.valueOf(operation.substring(n, n+1));
         index3 = n;
         }
    
        int numerator2 = Integer.valueOf(numerator2s);
        System.out.println(numerator2);
    
        
        int index4 = 0;
        String denominator2s = "";
        for (int n = index3 + 2; n < operation.indexOf(")", index2 + 2); n++){
         denominator2s += String.valueOf(operation.substring(n, n+1));
         index4 = n;
         }
    
        int denominator2 = Integer.valueOf(denominator2s);
        System.out.println(denominator2s);
        
 /////////////////////////// makes two fractions based off of the numbers grabbed
        
        Fraction fraction1 = new Fraction(numerator1, denominator1);
        Fraction fraction2 = new Fraction(numerator2, denominator2);

 /////////////////////////// adds, subtracts, multiplies, or divides fractions
        
         if (operation.substring(index2 + 2, index2 + 3).equals("+")){
          Fraction fraction3 = new Fraction(0,0);
          fraction3 = Fraction.simplify(Fraction.add(fraction1,fraction2));
          System.out.println(fraction3.getNumerator() + "/" + fraction3.getDenominator());
          }
    
         if (operation.substring(index2 + 2, index2 + 3).equals("-")){
          Fraction fraction3 = new Fraction(0,0);
          fraction3 = Fraction.simplify(Fraction.subtract(fraction1,fraction2));
          System.out.println(fraction3.getNumerator() + "/" + fraction3.getDenominator());
          }
    
         if (operation.substring(index2 + 2, index2 + 3).equals("*")){
          Fraction fraction3 = new Fraction(0,0);
          fraction3 = Fraction.simplify(Fraction.multiply(fraction1,fraction2));
          System.out.println(fraction3.getNumerator() + "/" + fraction3.getDenominator());
          }
    
         if (operation.substring(index2 + 2, index2 + 3).equals("/")){
          Fraction fraction3 = new Fraction(0,0);
          fraction3 = Fraction.simplify(Fraction.divide(fraction1,fraction2));
          System.out.println(fraction3.getNumerator() + "/" + fraction3.getDenominator());
          
          }

          
          }
  
          }
    
        
         
    }
}

